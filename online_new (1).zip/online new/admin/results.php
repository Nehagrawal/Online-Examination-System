<?php 
    getHeader(); 
    adminAccess();
    include_once('admin-menu.php');
?>
<?php getHeader(); ?>
<?php include_once('admin-menu.php'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-lg-12 col-md-12 lg-sm-12">
        <h2>Student Results</h2>
        </div>
    </div>
<hr>

<div class="container">
    <div class="row">
        <div class="table-responsive">
            <table class="table table-striped table-hover">
                <thead>
				    <tr>
				        <th>#</th>
				        <th>Student Name</th>
				        <th>Branch</th>
				        <th>Exam</th>
                        <th>Result</th>
                        <th>Percentage</th>
                    </tr>
				</thead>

                <tbody class="Videos">
<?php 
                    $i = 1;
                    $exams = queryMySQL("SELECT * FROM `results` WHERE 1");
                    foreach($exams as $x){
                    ?>                    <tr>
                        <td><?php echo $i++; ?></td>
                        <td><?php $sId  = $x['student_id'];
                                $sfName = queryMySQL("SELECT `firstname` FROM `students` WHERE `id` = '$sId'")->fetch_assoc()['firstname'];
                                $slName = queryMySQL("SELECT `lastname` FROM `students` WHERE `id` = '$sId'")->fetch_assoc()['lastname'];
                        $sName = $sfName.' '.$slName;
                        echo $sName; ?>
                    </td>                    

                         <?php 
                                $branch = queryMySQL("SELECT `name` FROM `branches` WHERE `id` = '$sId'")->fetch_assoc()['name'];
                    ?>
                        <td><b style="color:green"><?php echo $branch; ?></b></td>                        
                        <?php $xId = $x['exam_id'];
                                $xName = queryMySQL("SELECT `name` FROM `exams` WHERE `id` = '$xId'")->fetch_assoc()['name'];
                    ?>
                    <td style="color:darkslategrey"><?php echo $xName; ?></td>
                        <td style="color:darkgreen"><?php echo $x['result']; ?></td>
                        <td style="color:darkgreen"><?php echo $x['percentage']; ?></td>
                    </tr>
                    <?php } ?>

                        </tbody>
                    </table>
</div>
    <script>
        function deleteExam(id){
    
        bootbox.confirm("Are you sure?", function(result) {
            
            if(result){
                    window.location= 'delete-exam.php?id='+id;
            } else return false;
            
        }); 
    
    }
    </script>

        
<?php getFooter(); ?>